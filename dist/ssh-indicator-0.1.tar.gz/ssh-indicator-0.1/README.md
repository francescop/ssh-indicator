SSH Indicator
======================

The SSH indicator allows you to list your
ssh servers directly from your panel.

You can install it on Ubuntu from a PPA:

    sudo add-apt-repository ppa:palazzinifrancesco/utils
    sudo apt-get update
    sudo apt-get install ssh-indicator

DigitalOcean Indicator is licensed under the GPL 3.0.
